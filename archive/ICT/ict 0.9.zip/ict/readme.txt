internet browser compatibility
basically any internet browser support html5 audio tags and its functions and events.
chrome
firefox
safari
opera
ie9

release notes
version 0.9
improve ui edit mode and play mode html element settings.

version 0.8
start the site design on index.html
fix animation positions on the new design on index.html

version 0.7
remove not used code.
remove sound source of ogg type.
improve play tune sound by removing the duplicate play command.
add link to the readme.txt on the site.
add link to download the site on the site.

version 0.6
add name in the tune date and display it on site.
add shortcut (p) to play and pause tune.
highlight related point and list item when passing by.
display app version on the site.
clean old points and list item  before doing animation load.

version 0.5
fix defect in click point to jump in time

version 0.4
display time in big numbers in edit mode.
do not start animation unless the audio file is fully loaded.
sync audio placyer with the nimation. the animation can be started from the audio player. paused by the audio player seeked by the audio player.

version 0.3
change type of time in tune_data from integer to float
change time comparison syntax

version 0.2
changed filename js/ict_editor.js to tune_ui_text_mgmt.js
stop the nimation when the audio stops

version 0.1
The first working version. It is a concept one. It is still far from production.
