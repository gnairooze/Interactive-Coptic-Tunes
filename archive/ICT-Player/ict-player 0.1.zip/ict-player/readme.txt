internet browser compatibility
basically any internet browser support html5 audio tags and its functions and events.
chrome
firefox
safari
opera
ie9

release notes
version 0.1
created